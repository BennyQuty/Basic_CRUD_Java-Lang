package finalsproject;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Simple text file database to store and validate user credentials
 */
public class UserDatabase {
    
    // File to store user data
    private static final String USER_FILE = "userdata.txt";
    
    /**
     * Save a new user to the text file
     */
    public static boolean saveUser(String name, String username, String password) {
        // Check if username already exists
        if (checkUsername(username)) {
            return false; // Username already taken
        }
        
        try {
            // Open file in append mode
            FileWriter fw = new FileWriter(USER_FILE, true);
            // Write user data as name,username,password
            try (BufferedWriter bw = new BufferedWriter(fw)) {
                // Write user data as name,username,password
                bw.write(name + "," + username + "," + password);
                bw.newLine();
            }
            
            return true;
        } catch (IOException e) {
            System.out.println("Error saving user: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Check if username already exists
     */
    public static boolean checkUsername(String username) {
        try {
            File file = new File(USER_FILE);
            
            // If file doesn't exist yet, no usernames exist
            if (!file.exists()) {
                return false;
            }
            
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 2 && parts[1].equals(username)) {
                        br.close();
                        return true; // Username found
                    }
                }
            }
            return false; // Username not found
            
        } catch (IOException e) {
            System.out.println("Error checking username: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Validate user login credentials
     */
    public static boolean validateLogin(String username, String password) {
        try {
            File file = new File(USER_FILE);
            
            // If file doesn't exist yet, no valid logins
            if (!file.exists()) {
                return false;
            }
            
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3 && parts[1].equals(username) && parts[2].equals(password)) {
                        br.close();
                        return true; // Valid credentials
                    }
                }
            }
            return false; // Invalid credentials
            
        } catch (IOException e) {
            System.out.println("Error validating login: " + e.getMessage());
            return false;
        }
    }
    public static String getFullName(String username) {
    try {
        File file = new File(USER_FILE);
        if (!file.exists()) {
            return "";
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[1].equals(username)) {
                    return parts[0]; // Return the full name (1st item)
                }
            }
        }
    } catch (IOException e) {
        System.out.println("Error getting full name: " + e.getMessage());
    }

    return "";
}
}