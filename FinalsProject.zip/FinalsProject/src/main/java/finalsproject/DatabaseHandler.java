package finalsproject;

import java.io.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;

public class DatabaseHandler {

    public static final String DATA_DIR = "database/";
    private static final String PRODUCTS_FILE = DATA_DIR + "products.csv";
    

    static {
        File directory = new File(DATA_DIR);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        // Create products file if it doesn't exist
        File productsFile = new File(PRODUCTS_FILE);
        if (!productsFile.exists()) {
            try {
                productsFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Save product with user info
    public static boolean saveProduct(String id, String name, double price, int quantity, String category) {
        String username = Session.getUsername();
        if (username == null) return false;

        try {
            if (productExists(id)) return false;

            FileWriter fw = new FileWriter(PRODUCTS_FILE, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);

            out.println(id + "," + name + "," + price + "," + quantity + "," + category + "," + username);
            out.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Check if a product exists for this user
    public static boolean productExists(String id) {
        String username = Session.getUsername();
        if (username == null) return false;

        File file = new File(PRODUCTS_FILE);
        if (!file.exists()) return false;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;
                
                String[] data = line.split(",");
                if (data.length >= 6 && data[0].trim().equals(id.trim()) && data[5].trim().equals(username.trim())) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Load all products for current user
    public static DefaultTableModel loadAllProducts() {
        DefaultTableModel model = new DefaultTableModel(
            new String[] {"Product ID", "Product Name", "Product Price", "Quantity", "Category"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Make Product ID column non-editable
            }
        };

        String username = Session.getUsername();
        if (username == null) return model;

        File file = new File(PRODUCTS_FILE);
        if (!file.exists()) return model;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;
                
                String[] data = line.split(",");
                if (data.length >= 6 && data[5].trim().equals(username.trim())) {
                    try {
                        model.addRow(new Object[] {
                            data[0].trim(), 
                            data[1].trim(), 
                            Double.parseDouble(data[2].trim()),
                            Integer.parseInt(data[3].trim()), 
                            data[4].trim()
                        });
                    } catch (NumberFormatException e) {
                        System.err.println("Error parsing number in product data: " + line);
                        // Skip this line but continue processing others
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return model;
    }

    // Load products by category for current user
    public static DefaultTableModel loadProductsByCategory(String category) {
        DefaultTableModel model = new DefaultTableModel(
            new String[] {"Product ID", "Product Name", "Product Price", "Quantity", "Category"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Make Product ID column non-editable
            }
        };

        String username = Session.getUsername();
        if (username == null) return model;

        File file = new File(PRODUCTS_FILE);
        if (!file.exists()) return model;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;
                
                String[] data = line.split(",");
                if (data.length >= 6 && data[4].trim().equals(category.trim()) && data[5].trim().equals(username.trim())) {
                    try {
                        model.addRow(new Object[] {
                            data[0].trim(), 
                            data[1].trim(), 
                            Double.parseDouble(data[2].trim()),
                            Integer.parseInt(data[3].trim()), 
                            data[4].trim()
                        });
                    } catch (NumberFormatException e) {
                        System.err.println("Error parsing number in product data: " + line);
                        // Skip this line but continue processing others
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return model;
    }

    // Delete product
    public static boolean deleteProduct(String id) {
        String username = Session.getUsername();
        if (username == null) return false;

        File inputFile = new File(PRODUCTS_FILE);
        if (!inputFile.exists()) return false;
        
        File tempFile = new File(DATA_DIR + "temp.csv");
        boolean deleted = false;

        try (
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    writer.write(System.lineSeparator());
                    continue;
                }
                
                String[] data = line.split(",");
                if (data.length >= 6 && data[0].trim().equals(id.trim()) && data[5].trim().equals(username.trim())) {
                    deleted = true;
                    continue; // skip writing this line
                }
                writer.write(line + System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        if (!deleted) {
            tempFile.delete();
            return false;
        }

        inputFile.delete();
        return tempFile.renameTo(inputFile);
    }

    // Update product - Modified to properly handle strings and trimming
    public static boolean updateProduct(String id, String name, String price, String quantity, String category, String username) {
        if (username == null || username.trim().isEmpty()) {
            System.err.println("Username is null or empty");
            return false;
        }

        id = id.trim();
        username = username.trim();
        name = name.trim();
        price = price.trim();
        quantity = quantity.trim();
        category = category.trim();

        // Convert price and quantity to ensure they're valid numbers
        try {
            Double.parseDouble(price);
            Integer.parseInt(quantity);
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format: price=" + price + ", quantity=" + quantity);
            return false;
        }

        File inputFile = new File(PRODUCTS_FILE);
        if (!inputFile.exists()) {
            System.err.println("Products file does not exist: " + PRODUCTS_FILE);
            return false;
        }
        
        File tempFile = new File(DATA_DIR + "temp.csv");
        boolean updated = false;

        try (
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))
        ) {
            String currentLine;
            System.out.println("Looking to update product: " + id + " for user: " + username);

            while ((currentLine = reader.readLine()) != null) {
                currentLine = currentLine.trim();
                if (currentLine.isEmpty()) {
                    writer.write(System.lineSeparator());
                    continue;
                }
                
                String[] parts = currentLine.split(",");
                if (parts.length < 6) {
                    // Keep malformed lines as is
                    writer.write(currentLine + System.lineSeparator());
                    continue;
                }

                String currentId = parts[0].trim();
                String productOwner = parts[5].trim();
                
                System.out.println("Checking: ID=" + currentId + ", Owner=" + productOwner);

                if (currentId.equals(id) && productOwner.equals(username)) {
                    // Update the product line with all fields
                    // If category is not provided, keep existing category
                    String updatedCategory = (category.isEmpty()) ? parts[4].trim() : category;
                    String newLine = id + "," + name + "," + price + "," + quantity + "," + updatedCategory + "," + username;
                    writer.write(newLine + System.lineSeparator());
                    System.out.println("Updating product: " + newLine);
                    updated = true;
                } else {
                    // Copy the original line
                    writer.write(currentLine + System.lineSeparator());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        // Replace the original file with the updated temp file
        if (updated) {
            if (!inputFile.delete()) {
                System.err.println("Could not delete original file: " + inputFile.getAbsolutePath());
                return false;
            }
            if (!tempFile.renameTo(inputFile)) {
                System.err.println("Could not rename temp file: " + tempFile.getAbsolutePath() + " to " + inputFile.getAbsolutePath());
                return false;
            }
            System.out.println("Product updated successfully");
            return true;
        } else {
            // No matching ID found
            tempFile.delete(); // cleanup
            System.err.println("No product found with ID: " + id + " for user: " + username);
            return false;
        }
    }
    
    // Overload for backward compatibility
    public static boolean updateProduct(String id, String name, String price, String quantity, String username) {
        return updateProduct(id, name, price, quantity, "", username);
    }
    
    // New method for searching products
    public static DefaultTableModel searchProducts(String searchTerm) {
        DefaultTableModel model = new DefaultTableModel(
            new String[] {"Product ID", "Product Name", "Product Price", "Quantity", "Category"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Make Product ID column non-editable
            }
        };

        String username = Session.getUsername();
        if (username == null) return model;
        
        searchTerm = searchTerm.toLowerCase().trim();
        if (searchTerm.isEmpty()) {
            return loadAllProducts(); // If search term is empty, show all products
        }

        File file = new File(PRODUCTS_FILE);
        if (!file.exists()) return model;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;
                
                String[] data = line.split(",");
                if (data.length >= 6 && data[5].trim().equals(username.trim())) {
                    // Search in ID, name and category
                    boolean matches = data[0].toLowerCase().contains(searchTerm) ||
                                     data[1].toLowerCase().contains(searchTerm) ||
                                     data[4].toLowerCase().contains(searchTerm);
                    
                    if (matches) {
                        try {
                            model.addRow(new Object[] {
                                data[0].trim(), 
                                data[1].trim(), 
                                Double.parseDouble(data[2].trim()),
                                Integer.parseInt(data[3].trim()), 
                                data[4].trim()
                            });
                        } catch (NumberFormatException e) {
                            System.err.println("Error parsing number in product data: " + line);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return model;
    }
}