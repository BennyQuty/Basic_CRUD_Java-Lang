package finalsproject;

import java.io.*;
import java.util.*;

/**
 * User authentication handler for the inventory system
 * @author Tanaka
 */
public class UserAuth {
    
    // Path to the user database file
    private static final String DATA_DIR = "database/";
    private static final String USERS_FILE = DATA_DIR + "users.csv";
    
    // Create database directory if it doesn't exist
    static {
        File directory = new File(DATA_DIR);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        // Create a default admin user if users file doesn't exist
        File usersFile = new File(USERS_FILE);
        if (!usersFile.exists()) {
            try {
                FileWriter fw = new FileWriter(USERS_FILE);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw);
                
                // Add default admin user (username:admin, password:admin)
                out.println("admin,admin,Admin");
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Authenticate a user with username and password
     * @param username Username to authenticate
     * @param password Password to verify
     * @return User's display name if authenticated, null otherwise
     */
    public static String authenticateUser(String username, String password) {
        try {
            File file = new File(USERS_FILE);
            Scanner scanner = new Scanner(file);
            
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                
                if (data.length >= 3 && data[0].equals(username) && data[1].equals(password)) {
                    scanner.close();
                    return data[2]; // Return the display name
                }
            }
            scanner.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return null; // Authentication failed
    }
    
    /**
     * Register a new user
     * @param username Username for new user
     * @param password Password for new user
     * @param displayName Display name for new user
     * @return boolean indicating success
     */
    public static boolean registerUser(String username, String password, String displayName) {
        // Check if username already exists
        if (userExists(username)) {
            return false;
        }
        
        try {
            FileWriter fw = new FileWriter(USERS_FILE, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);
            
            out.println(username + "," + password + "," + displayName);
            out.close();
            
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Check if a username already exists
     * @param username Username to check
     * @return boolean indicating if user exists
     */
    public static boolean userExists(String username) {
        try {
            File file = new File(USERS_FILE);
            Scanner scanner = new Scanner(file);
            
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                
                if (data.length > 0 && data[0].equals(username)) {
                    scanner.close();
                    return true;
                }
            }
            scanner.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return false;
    }
}